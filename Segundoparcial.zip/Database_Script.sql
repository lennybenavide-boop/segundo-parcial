-- Creación de la Base de Datos y Tabla para la Segunda Evaluación Parcial
-- Estudiante: Lennyn Orlando Benavides Alvarenga
-- Carnet: 250551

IF DB_ID('ParcialProgramacion1') IS NULL
BEGIN
    CREATE DATABASE ParcialProgramacion1;
END;
GO

USE ParcialProgramacion1;
GO

IF OBJECT_ID('dbo.Productos', 'U') IS NOT NULL
    DROP TABLE dbo.Productos;
GO

CREATE TABLE dbo.Productos
(
    IdProducto INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(100) NOT NULL,
    Categoria NVARCHAR(50) NOT NULL,
    Precio DECIMAL(10,2) NOT NULL CHECK (Precio > 0),
    Existencias INT NOT NULL CHECK (Existencias >= 0)
);
GO

-- Registrar al menos tres productos de ejemplo
INSERT INTO dbo.Productos (Nombre, Categoria, Precio, Existencias) VALUES 
('Casco Integral LS2', 'Accesorios', 125.50, 15),
('Aceite Sintético 10W-40', 'Lubricantes', 14.99, 40),
('Guantes de Cuero Moto', 'Protección', 35.00, 25);
GO
